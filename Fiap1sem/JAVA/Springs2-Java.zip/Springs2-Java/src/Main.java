import Model.Atendente;
import Model.Oficina;
import Model.Usuario;
import Model.Veiculos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Usuario usuario1 = null;
        List<Veiculos> veiculosUsuario = new ArrayList<>();

        boolean running = true;
        while (running) {
            System.out.printf("""
                1-) Cadastrar-se
                2-) Logar a uma conta já existente
                3-) Trabalho na SAFECAR
                4-) Sair
                Escolha uma opção: """);

            int opcao = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (opcao) {
                case 1 -> {
                    usuario1 = new Usuario();
                    usuario1.cadastrarCliente();
                }
                case 2 -> {
                    if (usuario1 == null) {
                        System.out.println("Nenhum usuário cadastrado. Por favor, cadastre-se primeiro.");
                    } else if (usuario1.logarCliente()) {
                        System.out.printf("Entrando...\n");

                        boolean loggedIn = true;
                        while (loggedIn) {
                            System.out.printf("""
                                1-) Cadastrar veículo
                                2-) Mostrar veículos cadastrados
                                3-) Mostrar veiculso na oficina
                                4-) Oficina
                                5-) Sair
                                Escolha uma opção: """);

                            int subOpcao = sc.nextInt();
                            sc.nextLine(); // Consume newline

                            switch (subOpcao) {
                                case 1 -> {
                                    Veiculos veiculo1 = new Veiculos();
                                    veiculo1.cadastrarVeiculo();
                                    veiculosUsuario.add(veiculo1);

                                }
                                case 2 -> {
                                    if (veiculosUsuario.isEmpty()) {
                                        System.out.println("Nenhum veículo cadastrado.");
                                    } else {
                                        System.out.println("Veículos cadastrados:");
                                        for (Veiculos veiculo : veiculosUsuario) {
                                            System.out.println(veiculo.toString());
                                        }
                                    }
                                }
                                case 3 -> {
                                    List<Oficina> oficinas = new ArrayList<>();
                                    oficinas.add((Oficina) veiculosUsuario);
                                }
                                case 4 -> {
                                    loggedIn = false;
                                    System.out.println("Saindo...");
                                }
                                default -> System.out.println("Opção inválida, tente novamente.");
                            }
                        }
                    } else {
                        System.out.printf("Email ou senha incorretos.\n");
                    }
                }
                case 3 -> {
                    Atendente atendente1 = new Atendente();
                    atendente1.cadastrarAtendente(); // Atendente se cadastra
                    atendente1.logarAtendente(); // Atendente faz login
                }
                case 4 -> {
                    System.out.println("Opção Oficina selecionada.");
                    // Implementar lógica para oficina aqui
                }
                case 5 -> {
                    running = false;
                    System.out.println("Saindo...");
                }
                default -> System.out.println("Opção inválida, tente novamente.");
            }
        }
    }
}

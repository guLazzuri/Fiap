package Model;

import java.util.Scanner;

public class Atendente {
    private String nomeAtendente;
    private String emailAtendente;
    private String senhaAtendente;



    public String getNomeAtendente() {
        return nomeAtendente;
    }

    public void setNomeAtendente(String nomeAtendente) {
        this.nomeAtendente = nomeAtendente;
    }

    public String getSenhaAtendente() {
        return senhaAtendente;
    }

    public void setSenhaAtendente(String senhaAtendente) {
        this.senhaAtendente = senhaAtendente;
    }

    public String getEmailAtendente() {
        return emailAtendente;
    }

    public void setEmailAtendente(String emailAtendente) {
        this.emailAtendente = emailAtendente;
    }


    public void atenderMensagem(String mensagem) {
        System.out.println("Ola meu nome é "+ getNomeAtendente() + " e eu vou prosseguir com o atendimento.");
        System.out.println("Mensagem recebida: "+ " ' " + mensagem + " ' " + "é sobre esse tema que gostaria de seguir?");

    }

    public void resolverProblemas(String resposta) {
//        Nesse metodo a(o) atendente ira solucionar o problema da pessoa com o Chat
////        System.out.println(resposta);      ainda nao temos funcionarios nem probelmas para serem resaolvidos!
    }

    // Método para validar nome usando regex
    private boolean validarnomeAtendente(String nomeAtendente) {
        String nomeAtendenteRegex = "^[A-Z][a-z]+(?: [A-Z][a-z]+)*$";
        return nomeAtendente.matches(nomeAtendenteRegex);
    }

    // Método para validar email usando regex
    private boolean validarEmail(String emailAtendente) {
        String emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return emailAtendente.matches(emailRegex);
    }

    // Método para validar senha usando regex
    private boolean validarSenha(String senhaAtendente) {
        // Pelo menos 8 caracteres, pelo menos 1 letra maiúscula, 1 letra minúscula, 1 número e 1 caractere especial
        String senhaRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return senhaAtendente.matches(senhaRegex);
    }

    // Método para realizar o cadastro do Atendente
    public void cadastrarAtendente() {
        Scanner sc = new Scanner(System.in);

        do {
            System.out.printf("DIGITE SEU NOME: ");
            setNomeAtendente(sc.nextLine());
            if (!validarnomeAtendente(getNomeAtendente())){
                System.out.println("Nome inválido. Por favor, digite um nome válido.");
            }
        } while (!validarnomeAtendente(getNomeAtendente()));

        // Solicitar e validar o email
        do {
            System.out.print("DIGITE SEU EMAIL: ");
            setEmailAtendente(sc.nextLine());
            if (!validarEmail(getEmailAtendente())) {
                System.out.println("Email inválido. Por favor, digite um email válido.");
            }
        } while (!validarEmail(getEmailAtendente()));

        // Solicitar e validar a senha
        do {
            System.out.print("DIGITE SUA SENHA: ");
            setSenhaAtendente(sc.nextLine());
            if (!validarSenha(getSenhaAtendente())) {
                System.out.println("Senha inválida. Por favor, digite uma senha válida.\n");
                System.out.println("A senha deve ter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial.\n");
            }
        } while (!validarSenha(getSenhaAtendente()));

        // Confirmação de cadastro
        System.out.println("Cadastro realizado com sucesso!");
    }

    public void logarAtendente(){
        Scanner sc = new Scanner(System.in);
        System.out.printf("LOGIN INICIALIZADO! \n");
        System.out.print("Email:  ");
        String emailLoginAtendente = sc.nextLine();
        System.out.printf("Senha: ");
        String senhaLoginAtendente = sc.nextLine();

        if (getEmailAtendente().equals(emailLoginAtendente) && getSenhaAtendente().equals(senhaLoginAtendente)) {
            System.out.printf("Bem Vindo " + getNomeAtendente() +  " \n");
        }
        else {
            System.out.printf("Email ou senha incorreto\n");
        }
    }

}

package Model;

import java.util.ArrayList;
import java.util.List;

public class Chat {
    private List<String> mensagens;

    public Chat() {
        this.mensagens = new ArrayList<>();
    }

    public void enviarMensagem(String mensagem) {
        mensagens.add(mensagem);
    }

    public List<String> getMensagens() {
        return mensagens;
    }
}

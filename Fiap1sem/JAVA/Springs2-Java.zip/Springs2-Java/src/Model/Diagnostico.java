package Model;

public class Diagnostico {
}

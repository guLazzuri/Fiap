package Model;

public class HistoricoDeMensagem {
}

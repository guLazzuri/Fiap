package Model;

public class Orcamento {
    private int id;
    private String descricao;
    private double preco;

    public Orcamento(double preco, String descricao) {
        this.preco = preco;
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Orcamento{" +
                "descricao='" + descricao + '\'' +
                ", preco=" + preco +
                '}';
    }
}

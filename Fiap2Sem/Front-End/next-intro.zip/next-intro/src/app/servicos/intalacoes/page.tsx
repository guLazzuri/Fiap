export default  function Servicos(){
    return (
        <h1>Intelacoes</h1>
    )
}
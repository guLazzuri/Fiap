package Entidades;

import Validacao.ValidadorEntidades;

import java.util.List;
import java.util.Scanner;

public class Album extends _EntidadesBases {
    private String titulo;
    private int anoLancamento;
    private String artista;
    private List<Album> listaMusicas;

    public Album(){
    }

    public Album(int id, String titulo, int anoLancamento, String artista, List<Album> listaMusicas) {
        super(id);
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
        this.artista = artista;
        this.listaMusicas = listaMusicas;
    }

    Scanner sc = new Scanner(System.in);
    public void CadastrarAlbum(){
        System.out.println("Qual o nome do titulo do album?");
        setTitulo(sc.nextLine());
        System.out.println("Qual o ano do album?");
        setAnoLancamento(sc.nextInt());
        sc.nextLine();
        System.out.println("Qual o nome do artista do album?");
        setArtista(sc.nextLine());
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public List<Album> getListaMusicas() {
        return listaMusicas;
    }

    public void setListaMusicas(List<Album> listaMusicas) {
        this.listaMusicas = listaMusicas;
    }

    @Override
    public String toString() {
        return "Album{" +
                "titulo='" + titulo + '\'' +
                ", anoLancamento=" + anoLancamento +
                ", artista='" + artista + '\'' +
                ", listaMusicas=" + listaMusicas +
                "} " + super.toString();
    }
}

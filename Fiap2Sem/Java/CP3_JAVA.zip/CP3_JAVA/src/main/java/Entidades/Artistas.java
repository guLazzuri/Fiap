package Entidades;

import Validacao.ValidadorEntidades;

import java.util.List;
import java.util.Scanner;

public class Artistas extends _EntidadesBases {
    private String nome;
    private String generoMusical;
    private List<Album> listaAlbuns;
    Scanner sc = new Scanner(System.in);

    public Artistas() {
    }

    public Artistas(int id, String nome, String generoMusical, List<Album> albums) {
        super(id);
        this.nome = nome;
        this.generoMusical = generoMusical;
        this.listaAlbuns = albums;
    }

    public void CadastrarArtista() {
        try {
            System.out.println("Digite o nome do artista: ");
            String nome = sc.nextLine();
            ValidadorEntidades.ValidarArtistasNome(nome); // Valida o nome do artista
            this.setNome(nome);

            System.out.println("Digite o gênero do artista: ");
            String genero = sc.nextLine();
            ValidadorEntidades.ValidarGeneroMusical(genero); // Valida o gênero musical
            this.setGeneroMusical(genero);

            // Se chegou até aqui sem exceções, o cadastro foi bem-sucedido
            System.out.println("Artista cadastrado com sucesso!");

        } catch (Exception e) {
            // Se houve alguma exceção, o cadastro falhou
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGeneroMusical() {
        return generoMusical;
    }

    public void setGeneroMusical(String generoMusical) {
        this.generoMusical = generoMusical;
    }

    public List<Album> getAlbums() {
        return listaAlbuns;
    }

    public void setAlbums(List<Album> albums) {
        this.listaAlbuns = albums;
    }

    @Override
    public String toString() {
        return "Artistas{" +
                "nome='" + nome + '\'' +
                ", generoMusical='" + generoMusical + '\'' +
                ", albums=" + listaAlbuns +
                "} " + super.toString();
    }
}

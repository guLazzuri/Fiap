package Entidades;

import java.io.Serializable;
import java.util.Scanner;

public class Musica extends _EntidadesBases {
    private String titulo;
    private String album;
    private int duracao;

    public Musica(int id, String titulo, String album, int duracao) {
        super(id);
        this.titulo = titulo;
        this.album = album;
        this.duracao = duracao;
    }

    Scanner sc = new Scanner(System.in);
    public void CadastrarMusica() {
        System.out.println("Digite o titulo: ");
        titulo = sc.nextLine();
        System.out.println("Digite o album: ");
        album = sc.nextLine();
        System.out.println("Digite o duracao: ");
        duracao = sc.nextInt();
    }

    public Musica() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    @Override
    public String toString() {
        return "Musica{" +
                "titulo='" + titulo + '\'' +
                ", album='" + album + '\'' +
                ", duracao=" + duracao +
                "} " + super.toString();
    }
}

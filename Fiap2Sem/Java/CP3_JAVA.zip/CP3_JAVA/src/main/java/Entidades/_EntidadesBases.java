package Entidades;

public abstract class _EntidadesBases {
    private int id;
    private boolean deletar;
    private boolean publicar;


    public _EntidadesBases(int id) {
        this.id = id;
    }

    public _EntidadesBases() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isDeletar() {
        return deletar;
    }

    public void setDeletar(boolean deletar) {
        this.deletar = deletar;
    }

    public boolean isPublicar() {
        return publicar;
    }

    public void setPublicar(boolean publicar) {
        this.publicar = publicar;
    }

    @Override
    public String toString() {
        return "_EntidadesBases{" +
                "id=" + id +
                '}';
    }
}

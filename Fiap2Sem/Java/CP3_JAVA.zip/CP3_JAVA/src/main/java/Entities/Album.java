package Entities;

import java.util.ArrayList;
import java.util.List;

public class Album extends _BaseEntity {
    private String title;
    private String releaseYear;
    private String artist;
    private List<Music> musicList = new ArrayList<>();

    public Album(String id, String title, String releaseYear, String artist, List<Music> musicList) {
        super(id);
        this.title = title;
        this.releaseYear = releaseYear;
        this.artist = artist;
        this.musicList = (musicList != null) ? musicList : new ArrayList<>();
    }

    public Album() {
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(String releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public List<Music> getMusicList() {
        return musicList;
    }

    public void setMusicList(List<Music> musicList) {
        this.musicList = musicList;
    }

    @Override
    public String toString() {
        return "Album{" +
                "title='" + title + '\'' +
                ", releaseYear=" + releaseYear +
                ", artist='" + artist + '\'' +
                '}';
    }
}

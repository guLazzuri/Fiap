package Entities;

import java.util.ArrayList;
import java.util.List;

public class Artist extends _BaseEntity {
    private String name;
    private String musicGenre;
    private List<Album> albumList = new ArrayList<>();

    public Artist(String id, String name, String musicGenre, List<Album> albumList) {
        super(id);
        this.name = name;
        this.musicGenre = musicGenre;
        this.albumList = albumList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMusicGenre() {
        return musicGenre;
    }

    public void setMusicGenre(String musicGenre) {
        this.musicGenre = musicGenre;
    }

    public List<Album> getAlbumList() {
        return albumList;
    }

    public void setAlbumList(List<Album> albumList) {
        this.albumList = albumList;
    }

    @Override
    public String toString() {
        return "Artist{" +
                "id=" + getId() + // Inclua o id no toString
                ", name='" + name + '\'' +
                ", musicGenre='" + musicGenre + '\'' +
                ", albumList=" + albumList +
                '}';
    }
}

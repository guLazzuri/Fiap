package Entities;

public class Music extends _BaseEntity {
    private String title;
    private String album;
    private int duration; // Duration in minutes

    public Music(String id, String title, String album, int duration) {
        super(id);
        this.title = title;
        this.album = album;
        this.duration = duration;
    }

    public Music() {}

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Music{" +
                "title='" + title + '\'' +
                ", album='" + album + '\'' +
                ", duration=" + duration + " min" +
                '}';
    }
}

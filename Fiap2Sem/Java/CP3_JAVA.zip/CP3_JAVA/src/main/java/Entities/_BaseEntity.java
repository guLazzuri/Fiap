package Entities;

public abstract class _BaseEntity {
    private String id;
    private boolean deleted;
    private boolean published;

    public _BaseEntity(String id) {
        this.id = id;
    }

    public _BaseEntity() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean isPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }

    @Override
    public String toString() {
        return "BaseEntity{" +
                "id=" + id +
                ", deleted=" + deleted +
                ", published=" + published +
                '}';
    }
}

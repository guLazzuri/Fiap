package Menu;

import Entities.Album;
import Entities.Artist;
import Entities.Music;
import Repositories.ArtistRepository;
import Repositories.AlbumRepository;
import Repositories.MusicRepository;

import java.util.List;
import java.util.Scanner;

public class Menu {
    ArtistRepository artistRepo = new ArtistRepository();
    AlbumRepository albumRepo = new AlbumRepository();
    MusicRepository musicRepo = new MusicRepository();
    Scanner sc = new Scanner(System.in);

    public void showMenu() {
        int menuOption;
        do {
            // Displaying menu options
            System.out.println("Menu:");
            System.out.println("0. Exit");
            System.out.println("1. Register Artist");
            System.out.println("2. Register Album");
            System.out.println("3. Register Music");
            System.out.println("4. List Artists");
            System.out.println("5. Search Artist by Genre");
            System.out.println("6. Search Album by Year");

            // Receiving user's choice
            System.out.print("Choose an option: ");
            menuOption = sc.nextInt();
            sc.nextLine();

            // Processing the chosen option
            switch (menuOption) {
                case 1:
                    System.out.println("Registering Artist");
                    artistRepo.registerArtist(); // Method to register artist
                    break;
                case 2:
                    System.out.println("Registering Album");
                    albumRepo.registerAlbum(); // Method to register album
                    break;
                case 3:
                    System.out.println("Registering Music");
                    musicRepo.registerMusic(); // Method to register music
                    break;
                case 4:
                    System.out.println("Listing Artists:");
                    System.out.println(artistRepo.getAll());
                    break;
                case 5:
                    System.out.println("Enter the music genre you want to search:");
                    String genre = sc.nextLine();
                    List<Artist> genreList = artistRepo.searchByGenre(genre);
                    if (genreList.isEmpty()) {
                        System.out.println("No artists found in the genre: " + genre);
                    } else {
                        System.out.println("Artists found in the genre: " + genre);
                        for (Artist artist : genreList) {
                            System.out.println(artist.toString());
                        }
                    }
                    break;
                case 6:
                    System.out.println("Enter the year of the album you want to search:");
                    int year = sc.nextInt();
                    sc.nextLine();
                    List<Album> foundAlbums = albumRepo.searchByYear(year);
                    if (foundAlbums.isEmpty()) {
                        System.out.println("No albums found for the year " + year);
                    } else {
                        System.out.println("Found albums:");
                        for (Album album : foundAlbums) {
                            System.out.println(album);
                        }
                    }
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }

        } while (menuOption != 0);

        sc.close();
    }
}

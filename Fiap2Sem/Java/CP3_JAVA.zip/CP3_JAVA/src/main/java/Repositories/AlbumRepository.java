package Repositories;

import Entities.Album;
import Entities.Music;
import Validation.EntityValidator;
import utils.Log4jLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlbumRepository implements GenericRepository<Album> {
    private List<Album> albumList = new ArrayList<>();
    private Log4jLogger logger = new Log4jLogger(Album.class);

    @Override
    public void add(Album object) {
        logger.logCreate(object);
        albumList.add(object);
    }

    @Override
    public List<Album> getAll() {
        logger.logReadAll(null);
        return albumList;
    }

    @Override
    public void update(Album updatedAlbum) {
        for (int i = 0; i < albumList.size(); i++) {
            Album album = albumList.get(i);
            if (album.getId().equals(updatedAlbum.getId())) {
                albumList.set(i, updatedAlbum);
                logger.logUpdateById(updatedAlbum);
                return;
            }
        }
        // Handle case where album is not found, if necessary
    }

    @Override
    public void remove(Album object) {
        logger.logDeleteById(object);
        albumList.remove(object);
    }

    public void registerAlbum() {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Album ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Album Title: ");
            String title = sc.nextLine();
            EntityValidator.validateTitle(title);

            System.out.print("Enter Release Year: ");
            String releaseYear = sc.nextLine();
            EntityValidator.validateAlbumYear(releaseYear);

            System.out.print("Enter Artist: ");
            String artist = sc.nextLine();
            EntityValidator.validateArtistName(artist);

            List<Music> musicList = new ArrayList<>();
            Album album = new Album(id, title, releaseYear, artist, musicList);
            add(album);

            System.out.println("Album registered successfully!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public List<Album> searchByYear(int year) {
        List<Album> foundAlbums = new ArrayList<>();
        for (Album album : albumList) {
            try {
                if (Integer.parseInt(album.getReleaseYear()) == year) {
                    foundAlbums.add(album);
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return foundAlbums;
    }
}

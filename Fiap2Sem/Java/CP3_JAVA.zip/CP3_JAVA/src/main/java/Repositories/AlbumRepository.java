package Repositories;

import Entities.Album;
import Entities.Music;
import Validation.EntityValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlbumRepository extends GenericRepositoryImpl<Album> {

    public AlbumRepository() {
        super(Album.class);
    }

    public void registerAlbum() {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Album ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Album Title: ");
            String title = sc.nextLine();
            EntityValidator.validateTitle(title);

            System.out.print("Enter Release Year: ");
            String releaseYear = sc.nextLine();
            EntityValidator.validateAlbumYear(releaseYear);

            System.out.print("Enter Artist: ");
            String artist = sc.nextLine();
            EntityValidator.validateArtistName(artist);

            List<Music> musicList = new ArrayList<>();
            Album album = new Album(id, title, releaseYear, artist, musicList);
            add(album);

            System.out.println("Album registered successfully!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public List<Album> searchByYear(int year) {
        List<Album> foundAlbums = new ArrayList<>();
        for (Album album : entityList) {
            try {
                if (Integer.parseInt(album.getReleaseYear()) == year) {
                    foundAlbums.add(album);
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return foundAlbums;
    }
}

package Repositories;

import Entities.Album;
import Entities.Artist;
import Validation.EntityValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArtistRepository extends GenericRepositoryImpl<Artist> {

    public ArtistRepository() {
        super(Artist.class);
    }

    public void registerArtist() {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Artist ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Artist Name: ");
            String name = sc.nextLine();
            EntityValidator.validateArtistName(name);

            System.out.print("Enter Music Genre: ");
            String genre = sc.nextLine();
            EntityValidator.validateGenre(genre);

            List<Album> albumList = new ArrayList<>();
            Artist artist = new Artist(id, name, genre, albumList);
            add(artist);

            System.out.println("Artist registered successfully!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public List<Artist> searchByGenre(String genre) {
        List<Artist> foundArtists = new ArrayList<>();
        for (Artist artist : entityList) {
            if (artist.getMusicGenre().equalsIgnoreCase(genre)) {
                foundArtists.add(artist);
            }
        }
        return foundArtists;
    }
}

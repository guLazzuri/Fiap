package Repositories;

import Entities.Album;
import Entities.Artist;
import Validation.EntityValidator;
import utils.Log4jLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArtistRepository implements GenericRepository<Artist> {
    private List<Artist> artistList = new ArrayList<>();
    private Log4jLogger logger = new Log4jLogger(Artist.class);

    @Override
    public void add(Artist object) {
        logger.logCreate(object);
        artistList.add(object);
    }

    @Override
    public List<Artist> getAll() {
        logger.logReadAll(null);
        return artistList;
    }

    @Override
    public void update(Artist object) {
        logger.logDeleteById(object);
    }

    @Override
    public void remove(Artist object) {
        logger.logDeleteById(object);
        artistList.remove(object);
    }

    public void registerArtist() {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Artist ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Artist Name: ");
            String name = sc.nextLine();
            EntityValidator.validateArtistName(name);

            System.out.print("Enter Music Genre: ");
            String genre = sc.nextLine();
            EntityValidator.validateGenre(genre);


            List<Album> albumList = new ArrayList<>();
            Artist artist = new Artist(id, name, genre, albumList);
            add(artist);


        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public List<Artist> searchByGenre(String genre) {
        List<Artist> foundArtists = new ArrayList<>();
        for (Artist artist : artistList) {
            if (artist.getMusicGenre().equalsIgnoreCase(genre)) {
                foundArtists.add(artist);
            }
        }
        return foundArtists;
    }
}

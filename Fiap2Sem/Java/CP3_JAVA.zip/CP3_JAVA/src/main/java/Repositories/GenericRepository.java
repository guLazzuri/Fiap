package Repositories;

import Entities._BaseEntity;
import java.util.List;

public interface GenericRepository<T extends _BaseEntity> {
        void add(T entity);
        List<T> getAll();
        void update(T entity);
        void remove(T entity);
}

package Repositories;

import Entities._BaseEntity;
import utils.Log4jLogger;
import java.util.List;

public class GenericRepositoryImpl<T extends _BaseEntity> implements GenericRepository<T> {
    protected Log4jLogger logger;

    public GenericRepositoryImpl(Class<T> tClass) {
        this.logger = new Log4jLogger(tClass);
    }

    @Override
    public void add(T entity) {
        logger.logCreate(entity);
    }

    @Override
    public List<T> getAll() {
        return List.of();
    }

    @Override
    public void update(T entity) {
    }

    @Override
    public void remove(T entity) {
    }
}

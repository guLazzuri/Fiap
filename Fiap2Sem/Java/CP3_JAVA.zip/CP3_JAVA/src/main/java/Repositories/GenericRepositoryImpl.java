package Repositories;

import Entities._BaseEntity;
import utils.Log4jLogger;

import java.util.ArrayList;
import java.util.List;

public class GenericRepositoryImpl<T extends _BaseEntity> implements GenericRepository<T> {
    protected List<T> entityList = new ArrayList<>();
    protected Log4jLogger logger;

    public GenericRepositoryImpl(Class<T> tClass) {
        this.logger = new Log4jLogger(tClass);
    }

    @Override
    public void add(T entity) {
        logger.logCreate(entity);
        entityList.add(entity);
    }

    @Override
    public List<T> getAll() {
        logger.logReadAll(null);
        return new ArrayList<>(entityList);
    }

    @Override
    public void update(T updatedEntity) {
        for (int i = 0; i < entityList.size(); i++) {
            T entity = entityList.get(i);
            if (entity.getId().equals(updatedEntity.getId())) {
                entityList.set(i, updatedEntity);
                logger.logUpdateById(updatedEntity);
                return;
            }
        }
    }

    @Override
    public void remove(T entity) {
        logger.logDeleteById(entity);
        entityList.remove(entity);
    }
}

package Repositories;

import Entities.Music;
import Validation.EntityValidator;

import java.util.Scanner;

public class MusicRepository extends GenericRepositoryImpl<Music> {

    public MusicRepository() {
        super(Music.class);
    }

    public void registerMusic() {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter Music ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Music Title: ");
            String title = sc.nextLine();
            EntityValidator.validateTitle(title);

            System.out.print("Enter Album: ");
            String album = sc.nextLine();
            EntityValidator.validateAlbum(album);

            System.out.print("Enter Duration (in minutes): ");
            int duration = sc.nextInt();
            EntityValidator.validateDuration(duration);

            Music music = new Music(id, title, album, duration);
            add(music);

            System.out.println("Music registered successfully!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

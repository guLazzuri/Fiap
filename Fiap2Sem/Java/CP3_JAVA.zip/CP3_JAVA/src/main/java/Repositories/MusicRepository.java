package Repositories;

import Entities.Music;
import Validation.EntityValidator;
import utils.Log4jLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MusicRepository implements GenericRepository<Music> {
    private List<Music> musicList = new ArrayList<>();
    private Log4jLogger logger = new Log4jLogger(Music.class);

    @Override
    public void add(Music object) {
        logger.logCreate(object);
        musicList.add(object);
    }

    @Override
    public List<Music> getAll() {
        logger.logReadAll(null);
        return musicList;
    }

    @Override
    public void update(Music object) {
        logger.logUpdateById(object);
    }

    @Override
    public void remove(Music object) {
        logger.logDeleteById(object);
        musicList.remove(object);
    }

    public void registerMusic() {
        Scanner sc = new Scanner(System.in);

        try{
            System.out.print("Enter Music ID: ");
            String id = sc.nextLine();
            EntityValidator.validateID(id);

            System.out.print("Enter Music Title: ");
            String title = sc.nextLine();
            EntityValidator.validateTitle(title);

            System.out.print("Enter Album: ");
            String album = sc.nextLine();
            EntityValidator.validateAlbum(album);

            System.out.print("Enter Duration (in minutes): ");
            int duration = sc.nextInt();
            EntityValidator.validateDuration(duration);

            Music music = new Music(id, title, album, duration);
            add(music);

        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }

    }
}

package Repositorios;

import Entidades.Album;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Repositorio_Album implements Repositorio_Generico<Album> {
    private List<Album> listaDeAlbum = new ArrayList<>();

    public List<Album> BuscarPorAno(int ano) {
        return listaDeAlbum.stream()
                .filter(album -> album.getAnoLancamento() == ano)
                .collect(Collectors.toList());
    }

    @Override
    public void adicionar(Album objeto) {
            listaDeAlbum.add(objeto);
    }

    @Override
    public List<Album> listar() {
        return listaDeAlbum;
    }

    @Override
    public void atualizar(Album objeto) {

    }

    @Override
    public void remover(Album objeto) {
        listaDeAlbum.remove(objeto);
    }
}

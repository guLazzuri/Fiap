package Repositorios;
import Entidades.Artistas;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Repositorio_Artista implements Repositorio_Generico<Artistas> {
    private List<Artistas> listaDeartistas = new ArrayList<Artistas>();


    @Override
    public void adicionar(Artistas objeto) {
        listaDeartistas.add(objeto);
    }

    @Override
    public List<Artistas> listar() {
        return listaDeartistas;
    }

    @Override
    public void atualizar(Artistas objeto) {

    }

    @Override
    public void remover(Artistas obejto) {
        listaDeartistas.remove(obejto);
    }

    public List<Artistas> BuscarPorGenero(String genero) {
        return listaDeartistas.stream()
                .filter(artistas -> artistas.getGeneroMusical()
                        .equalsIgnoreCase(genero))
                .collect(Collectors.toList());

    }
}
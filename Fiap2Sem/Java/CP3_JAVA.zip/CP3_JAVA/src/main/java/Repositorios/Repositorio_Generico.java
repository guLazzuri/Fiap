package Repositorios;
import Entidades._EntidadesBases;
import java.util.List;

public  interface Repositorio_Generico<T extends _EntidadesBases> {
        void adicionar (T objeto);
        List<T> listar();
        void atualizar(T objeto);
        void remover(T obejto);
}

package Repositorios;

import Entidades.Musica;

import java.util.ArrayList;

public class Repositorio_Musica implements Repositorio_Generico<Musica> {

    @Override
    public void adicionar(Musica objeto) {
    }

    @Override
    public ArrayList<Musica> listar() {
        return null;
    }

    @Override
    public void atualizar(Musica objeto) {
    }

    @Override
    public void remover(Musica obejto) {
    }
}

package Validacao;

import Entidades.Album;
import Entidades.Artistas;
import Entidades.Musica;

public class ValidadorEntidades {

    public static void ValidarArtistasNome(String nome) throws Exception {
        if (nome == null || nome.isEmpty()) {
            throw new Exception("O nome do artista não pode ser nulo ou vazio.");
        }
    }

    public static void ValidarGeneroMusical(String genero) throws Exception {
        if (genero == null || genero.isEmpty()) {
            throw new Exception("O gênero musical do artista não pode ser nulo ou vazio.");
        }
        if (genero.matches(".*\\d.*")) {
            throw new Exception("O gênero do artista não deve conter números.");
        }
    }

    public static void ValidarAlbum(Album album) throws Exception {
        if (album.getAnoLancamento() <= 0 || album.getAnoLancamento() < 1900) {
            throw new Exception("O ano de lançamento do álbum é inválido.");
        }
    }

    public static void ValidarMusicas(Musica musica) throws Exception {
        if (musica.getDuracao() <= 0) {
            throw new Exception("A duração da música não pode ser menor ou igual a zero.");
        }
    }
}

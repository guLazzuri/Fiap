package Validation;

public class EntityValidator {
    public static void validateTitle(String title) throws Exception {
        if (title == null || title.trim().isEmpty()) {
            throw new Exception("Title cannot be empty");
        }
        if (title.length() > 100) { // Exemplo de comprimento máximo
            throw new Exception("Title cannot be longer than 100 characters");
        }
    }

    public static void validateArtistName(String name) throws Exception {
        if (name == null || name.trim().isEmpty()) {
            throw new Exception("Artist name cannot be empty");
        }
        if (name.length() > 100) { // Exemplo de comprimento máximo
            throw new Exception("Artist name cannot be longer than 100 characters");
        }
    }

    public static void validateAlbum(String album) throws Exception {
        if (album == null || album.trim().isEmpty()) {
            throw new Exception("Album cannot be empty");
        }
        if (album.length() > 100) { // Exemplo de comprimento máximo
            throw new Exception("Album name cannot be longer than 100 characters");
        }
    }

    public static void validateGenre(String genre) throws Exception {
        if (genre == null || genre.trim().isEmpty()) {
            throw new Exception("Genre cannot be empty");
        }
        if (genre.length() > 50) { // Exemplo de comprimento máximo
            throw new Exception("Genre cannot be longer than 50 characters");
        }
    }

    public static void validateID(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new Exception("ID cannot be empty");
        }

        // Remove possíveis espaços em branco antes e depois do ID
        id = id.trim();

        // Verifica se o ID contém apenas dígitos
        if (!id.matches("\\d+")) {
            throw new Exception("ID must contain only numeric characters");
        }

        // Verifica o comprimento do ID (opcional)
        if (id.length() < 1 || id.length() > 10) {
            throw new Exception("ID must be between 1 and 10 digits");
        }

        // Adicionar verificação para ID único no repositório, se aplicável
        // Exemplo: verificar se o ID já existe em um repositório
    }

    public static void validateAlbumYear(String year) throws Exception {
        if (year == null || year.trim().isEmpty()) {
            throw new Exception("Release year cannot be empty");
        }

        try {
            int releaseYear = Integer.parseInt(year);
            if (releaseYear < 1900 || releaseYear > 2100) {
                throw new Exception("Year must be between 1900 and 2100");
            }
        } catch (NumberFormatException e) {
            throw new Exception("Year must be a numeric value");
        }
    }

    public static void validateDuration(int duration) throws Exception {
        if (duration <= 0) {
            throw new Exception("Duration must be positive");
        }
        if (duration > 3600) { // Exemplo de duração máxima de 1 hora
            throw new Exception("Duration cannot exceed 3600 minutes (60 hours)");
        }
    }
}

package org.example;

import Entidades.Album;
import Entidades.Artistas;
import Entidades.Musica;
import Repositorios.Repositorio_Album;
import Repositorios.Repositorio_Artista;
import Repositorios.Repositorio_Musica;
import Validacao.ValidadorEntidades;

import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Repositorio_Artista repArtista = new Repositorio_Artista();
        Repositorio_Album repAlbum = new Repositorio_Album();
        Repositorio_Musica repMusica = new Repositorio_Musica();

        Scanner sc = new Scanner(System.in);
        int opcaMenu;

        do {
            System.out.println("Menu:");
            System.out.println("0. Sair");
            System.out.println("1. Cadastrar Artista");
            System.out.println("2. Cadastrar Álbum");
            System.out.println("3. Cadastrar Música");
            System.out.println("4. Listar Artistas");
            System.out.println("5. Buscar Artista por Gênero");
            System.out.println("6. Buscar Álbum por Ano");

            System.out.print("Escolha uma opção: ");
            opcaMenu = sc.nextInt();
            sc.nextLine();

            switch (opcaMenu) {
                case 1:
                    System.out.println("Cadastrando Artista:");
                    Artistas artista = new Artistas();
                    artista.CadastrarArtista();
                    repArtista.adicionar(artista);
                    System.out.println("Artista cadastrado com sucesso!");
                    break;

                case 2:
                    System.out.println("Cadastrando Álbum:");
                    Album album = new Album();
                    album.CadastrarAlbum();
                    try {
                        ValidadorEntidades.ValidarAlbum(album);
                        repAlbum.adicionar(album);
                        System.out.println("Álbum cadastrado com sucesso!");
                    } catch (Exception e) {
                        System.out.println("Erro ao cadastrar Álbum: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.println("Cadastrando Música:");
                    Musica musica = new Musica();
                    musica.CadastrarMusica();
                    try {
                        ValidadorEntidades.ValidarMusicas(musica);
                        repMusica.adicionar(musica);
                        System.out.println("Música cadastrada com sucesso!");
                    } catch (Exception e) {
                        System.out.println("Erro ao cadastrar Música: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.println("Listando Artistas:");
                    List<Artistas> artistasList = repArtista.listar();
                    for (Artistas art : artistasList) {
                        System.out.println(art);
                    }
                    break;

                case 5:
                    System.out.println("Digite o gênero musical que deseja buscar:");
                    String genero = sc.nextLine();
                    List<Artistas> artistasGenero = repArtista.BuscarPorGenero(genero);
                    if (artistasGenero.isEmpty()) {
                        System.out.println("Nenhum artista encontrado para o gênero " + genero);
                    } else {
                        for (Artistas art : artistasGenero) {
                            System.out.println(art);
                        }
                    }
                    break;

                case 6:
                    System.out.println("Digite o ano do álbum que deseja buscar:");
                    int ano = sc.nextInt();
                    sc.nextLine(); // Limpar o buffer
                    List<Album> albunsAno = repAlbum.BuscarPorAno(ano);
                    if (albunsAno.isEmpty()) {
                        System.out.println("Nenhum álbum encontrado para o ano " + ano);
                    } else {
                        for (Album alb : albunsAno) {
                            System.out.println(alb);
                        }
                    }
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida.");
                    break;
            }

        } while (opcaMenu != 0);

        sc.close();
    }
}

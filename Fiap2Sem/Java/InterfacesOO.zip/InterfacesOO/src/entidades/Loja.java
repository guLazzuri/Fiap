package entidades;

public class Loja extends _EntidadeBase {
    private String nome;
    private String email;
    private String cnpj;
}

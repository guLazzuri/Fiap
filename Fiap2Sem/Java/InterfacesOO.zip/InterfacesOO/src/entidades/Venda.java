package entidades;

public class Venda extends _EntidadeBase {
}

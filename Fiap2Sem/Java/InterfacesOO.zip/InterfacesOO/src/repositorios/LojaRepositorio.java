package repositorios;

import entidades.Loja;

public class LojaRepositorio extends _RepositorioBaseImpl<Loja> {
}

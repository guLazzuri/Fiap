package repositorios;

import entidades.Venda;

public class VendaRepositorio extends _RepositorioBaseImpl<Venda> {

}

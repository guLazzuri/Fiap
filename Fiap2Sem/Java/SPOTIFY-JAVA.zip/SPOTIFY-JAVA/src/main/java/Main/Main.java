package Main;

import Repositories.ArtistRepositories;
import entities.Artist;

public class Main {
    public static void main(String[] args) {

        var artistRpositories = new ArtistRepositories();

        //artistRpositories.Insert(new Artist("PEDRO", "pop"));
        //artistRpositories.Delete(1);
        //System.out.println(artistRpositories.GetById(1));
        //System.out.println(artistRpositories.GetAll());

    }
}